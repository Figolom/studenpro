echo -e '\033]2;MTP (XZC) - mintpond pool\007'
./CryptoDredge -a mtp -o stratum+ssl://zcoin.mintpond.com:3005 -u a2VcGTRJ8g5NAWQ1pxYUcUVyHpWA2k9BEx -p x
printf "Press <ENTER> to continue..."
read -r continueKey
